# ViewPagerCards
Developing ViewPager cards like Duolingo application in Android.
<br/>
![alt tag](http://i.imgur.com/UXpVigQ.gif)
